#Tesseract_Ocr
#项目的开源地址http://code.google.com/p/tesseract-ocr
#版本说明
	zlib 1.2.7
	lpng1514
	jpegsr9
	tiff-4.0.3
	giflib-5.0.4
	leptonica-1.69
	tesseract-ocr3.0.2
#开源项目说明
	光学字符识别(OCR,Optical Character Recognition)是指对文本资料进行扫描，然后对图像文件进行分析处理，获取文字及版面信息的过程。OCR技术非常专业，一般多是印刷、打印行业的从业人员使用，可以快速的将纸质资料转换为电子资料。关于中文OCR，目前国内水平较高的有清华文通、汉王、尚书，其产品各有千秋，价格不菲。国外OCR发展较早，像一些大公司，如IBM、微软、HP等，即使没有推出单独的OCR产品，但是他们的研发团队早已掌握核心技术，将OCR功能植入了自身的软件系统。
#更新记录
#2014/11/10
	1.移植Tesseract_Ocr开源项目到vs2010下面
	2.做了一个测试程序